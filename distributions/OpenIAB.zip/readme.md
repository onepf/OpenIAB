Sample Life game with in-app purchases
